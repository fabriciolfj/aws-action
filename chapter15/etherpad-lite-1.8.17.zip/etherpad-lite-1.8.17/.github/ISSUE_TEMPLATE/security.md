* * *

name: Security notification
about: Disclose a security issue in Etherpad
title: ''
labels: security
assignees: 

* * *

**Our Security disclosure process**
1. Please email contact@etherpad.org with detials of the exploit including steps to replicate.
1. Once confirmed we will provide a confirmation, patch and CVE details.
