'use strict';

module.exports = require('underscore');
