# Cypress Etherpad guide
We don't install Etherpad as a dev dep or dep within Etherpad because it's not
our core Frontend testing tool

## Quick start
```
npm i -g cypress
cd src/tests/frontend/cypress/
cypress open
```
