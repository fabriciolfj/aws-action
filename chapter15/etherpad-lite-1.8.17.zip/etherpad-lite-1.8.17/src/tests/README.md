# About this folder: Tests

Before running the tests, start an Etherpad instance on your machine.

## Frontend

To run the frontend tests, point your browser to `<yourdomainhere>/tests/frontend`

## Backend

To run the backend tests, run `cd src` and then `npm test`
